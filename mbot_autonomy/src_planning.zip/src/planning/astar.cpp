// // #include <planning/astar.hpp>
// // #include <algorithm>
// // #include <chrono>

// // using namespace std::chrono;

// // mbot_lcm_msgs::path2D_t search_for_path(mbot_lcm_msgs::pose2D_t start,
// //                                              mbot_lcm_msgs::pose2D_t goal,
// //                                              const ObstacleDistanceGrid& distances,
// //                                              const SearchParams& params)
// // {
// //     cell_t startCell = global_position_to_grid_cell(Point<double>(start.x, start.y), distances);
// //     cell_t goalCell = global_position_to_grid_cell(Point<double>(goal.x, goal.y), distances);
// //     bool found_path = false;
    
// //     ////////////////// TODO: Implement your A* search here //////////////////////////
    
// //     Node* startNode = new Node(startCell.x, startCell.y);
// //     Node* goalNode = new Node(goalCell.x, goalCell.y);
    

// //     mbot_lcm_msgs::path2D_t path;
// //     path.utime = start.utime;
// //     if (found_path)
// //     {
// //         auto nodePath = extract_node_path(goalNode, startNode);
// //         path.path = extract_pose_path(nodePath, distances);
// //         // Remove last pose, and add the goal pose
// //         path.path.pop_back();
// //         path.path.push_back(goal);
// //     }

// //     else printf("[A*] Didn't find a path\n");
// //     path.path_length = path.path.size();
// //     return path;
// // }



// // double h_cost(Node* from, Node* goal, const ObstacleDistanceGrid& distances)
// // {
// //     double h_cost = 0.0;
// //     ////////////////// TODO: Implement your heuristic //////////////////////////
    
// //     return h_cost;
// // }
// // double g_cost(Node* from, Node* goal, const ObstacleDistanceGrid& distances, const SearchParams& params)
// // {
// //     double g_cost = 0.0;
// //     ////////////////// TODO: Implement your goal cost, use obstacle distances //////////////////////////
    
// //     return g_cost;
// // }

// // std::vector<Node*> expand_node(Node* node, const ObstacleDistanceGrid& distances, const SearchParams& params)
// // {
// //     std::vector<Node*> children;
// //     ////////////////// TODO: Implement your expand node algorithm //////////////////////////
    
// //     return children;
// // }

// // std::vector<Node*> extract_node_path(Node* goal_node, Node* start_node)
// // {
// //     std::vector<Node*> path;
// //     ////////////////// TODO: Implement your extract node function //////////////////////////
// //     // Traverse nodes and add parent nodes to the vector
    
// //     // Reverse path
// //     std::reverse(path.begin(), path.end());
// //     return path;
// // }
// // // To prune the path for the waypoint follower
// // std::vector<mbot_lcm_msgs::pose2D_t> extract_pose_path(std::vector<Node*> nodes, const ObstacleDistanceGrid& distances)
// // {
// //     std::vector<mbot_lcm_msgs::pose2D_t> path;
// //     ////////////////// TODO: Implement your extract_pose_path function //////////////////////////
// //     // This should turn the node path into a vector of poses (with heading) in the global frame
// //     // You should prune the path to get a waypoint path suitable for sending to motion controller
    
    
// //     return path;
// // }

// // bool is_in_list(Node* node, std::vector<Node*> list)
// // {
// //     for (auto &&item : list)
// //     {
// //         if (*node == *item) return true;
// //     }
// //     return false;
// // }

// // Node* get_from_list(Node* node, std::vector<Node*> list)
// // {
// //     for (auto &&n : list)
// //     {
// //         if (*node == *n) return n;
// //     }
// //     return NULL;

// // }

// // std::vector<Node*> prune_node_path(std::vector<Node*> nodePath)
// // {
// //     std::vector<Node*> new_node_path;
// //     ////////////////// TODO: Optionally implement a prune_node_path function //////////////////////////
// //     // This should remove points in the path along the same line
    
// //     return new_node_path;

// // }











// #include <planning/astar.hpp>
// #include <algorithm>
// #include <chrono>
// #include <math.h>
// #include <cmath>
// #include <iostream>
// #include <thread>

// using namespace std::chrono;

// cell_t determine_closest_open_bfs(cell_t origin, const ObstacleDistanceGrid& distances, const SearchParams& params){
//     const int max_search_radius = 10;
//     cell_t point = origin;
//     int searched_radius = 0;
//     while (distances(point.x, point.y)<1.5*params.minDistanceToObstacle){
//         printf("searched point x%d, y%d\n", point.x, point.y);
//         cell_t child_cell[4];
//         child_cell[0] = point;
//         child_cell[0].x-=1;
//         child_cell[1] = point;
//         child_cell[1].x+=1;
//         child_cell[2] = point;
//         child_cell[2].y-=1;
//         child_cell[3] = point;
//         child_cell[3].y+=1;
//         double max_dists = 0;
//         for (int i =0; i<4; ++i){
//             double dist = distances(child_cell[i].x, child_cell[i].y);
//             if (dist>max_dists){
//                 point = child_cell[i];
//                 max_dists = dist;
//             }
//         }
//         if (searched_radius>max_search_radius){
//             return origin;
//         }
//         searched_radius++;
//     }
//     return point;
// }

// mbot_lcm_msgs::path2D_t search_for_path(mbot_lcm_msgs::pose2D_t start,
//                                              mbot_lcm_msgs::pose2D_t goal,
//                                              const ObstacleDistanceGrid& distances,
//                                              const SearchParams& params)
// {
//     cell_t startCell = global_position_to_grid_cell(Point<double>(start.x, start.y), distances);
//     cell_t goalCell = global_position_to_grid_cell(Point<double>(goal.x, goal.y), distances);
//     printf("PLANNING PATH TO: x:%d y:%d from current pose: x:%d y:%d\n", goalCell.x, goalCell.y, startCell.x, startCell.y);
//     bool found_path = false;
    
//     ////////////////// TODO: Implement your A* search here //////////////////////////
    
//     Node* startNode = new Node(startCell.x, startCell.y);
//     Node* goalNode = new Node(goalCell.x, goalCell.y);

//     //printf("in astar goal %f x %f y goalCell %d x %d y\n", goal.x, goal.y, goalCell.x, goalCell.y);
//     //printf("in astar cells per meter %f height in cells %d width in cells %d height in meters %f width in meters %f\n", distances.cellsPerMeter(), distances.heightInCells(), distances.widthInCells(), distances.heightInMeters(), distances.widthInMeters());

//     mbot_lcm_msgs::path2D_t path;
//     path.utime = start.utime;

//     PriorityQueue searched;
//     //int searched[distances.heightInCells()][distances.widthInCells()];
//     //for (int i = 0; i < distances.heightInCells(); i++) {
//     //    for (int j = 0; j < distances.widthInCells(); j++) {
//     //        searched[i][j] = 0;
//     //    }
//     //}
//     PriorityQueue closed_set;
//     PriorityQueue open_set;
//     Compare_Node cn;

//     //printf("STARTING A STAR SEARCH\n");
//     open_set.push(startNode);

//     Node* end;

//     while (!found_path) {
//         if (open_set.empty()) {
//             break;
//         }
//         //std::cout << "open set size " << open_set.elements.size() << std::endl;
//         Node* current = open_set.pop();
//         //printf("current x %d y %d\n", current->cell.x, current->cell.y);
//         if (current->cell.x == goalNode->cell.x && current->cell.y == goalNode->cell.y) {
//             found_path = true;
//             end = current;
//             break;
//         }
//         closed_set.push(current);
//         if (closed_set.elements.size()>150000){
//             double smallest_heuristic = closed_set.elements[0]->h_cost;
//             for (const auto &i : closed_set.elements){
//                 double h = i->h_cost;
//                 if (h<smallest_heuristic){
//                     end  = i;
//                     smallest_heuristic = h;
//                     found_path = true;
//                 }

//             }
//             printf("nearest optimal point in closed list is %d %d robot is on %d %d, smallest heuristic %f\n", end->cell.x, end->cell.y, current->cell.x, current->cell.y, smallest_heuristic);
//             break;
//         }
//         //std::cout << "closed set size " << closed_set.elements.size() << std::endl;
        
//         std::vector<Node*> children = expand_node(current, distances, params, searched);
//         for (int i = 0; i < children.size(); i++) {
//             Node* child = children[i];
//             if (!(closed_set.is_member(child) && distances.isCellInGrid(child->cell.x, child->cell.y)) && !(distances(child->cell.x, child->cell.y) < params.minDistanceToObstacle)) {
//                 if (!(searched.is_member(child))) {
//                     child->g_cost = g_cost(current, child, distances, params);
//                     child->h_cost = h_cost(child, goalNode, distances);
//                     child->parent = current;
//                     open_set.push(child);
//                     searched.push(child);
//                 } else if (child->g_cost > g_cost(current, child, distances, params)) {
//                     child->g_cost = g_cost(current, child, distances, params);
//                     child->parent = current;
//                     open_set.push(child);
//                 }
//             }
//         }
//     }

//     if (found_path)
//     {
//         //printf("FOUND PATH\n");
//         auto nodePath = extract_node_path(end, startNode);
//         path.path = extract_pose_path(nodePath, distances);
//         // Remove last pose, and add the goal pose
//         path.path.pop_back();
//         path.path.push_back(goal);
//         path = prune_node_path(path);
//         if (path.path.size() < 2){
//             path.path.clear();
//             path.path_length = 0;
//             printf("[A*] Didn't find a path\n");
//             std::this_thread::sleep_for(milliseconds(100));
//         }
//     }

//     else {
//         printf("[A*] Didn't find a path\n");
//         // std::sleep(5000);
//         // check if too close to wall
//         if ((distances(startCell.x, startCell.y) < params.minDistanceToObstacle)){
//             printf("point is stuck inside of wall, trying to exit \n");
//             //try to get out by turning around and exiting
//             cell_t goal_cell = determine_closest_open_bfs(startCell, distances, params);
//             mbot_lcm_msgs::pose2D_t goal;
//             mbot_lcm_msgs::pose2D_t temp_further_goal;

            
//             goal.x = (goal_cell.x) * distances.metersPerCell() + distances.originInGlobalFrame().x;
//             goal.y = (goal_cell.y) * distances.metersPerCell() + distances.originInGlobalFrame().y;
//             temp_further_goal.x = (goal_cell.x+goal_cell.x-startCell.x) * distances.metersPerCell() + distances.originInGlobalFrame().x;
//             temp_further_goal.y = (goal_cell.y+goal_cell.y-startCell.y) * distances.metersPerCell() + distances.originInGlobalFrame().y;
//             printf("final goal %f %f \n", goal.x, goal.y);

//             path.path.push_back(goal);
//             path.path.push_back(temp_further_goal);
//         }
//         else{
//             std::this_thread::sleep_for(milliseconds(100));
//         }

//     }
//     path.path_length = path.path.size();
//     return path;
// }



// double h_cost(Node* from, Node* goal, const ObstacleDistanceGrid& distances)
// {
//     //double h_cost = 0.0;
//     ////////////////// TODO: Implement your heuristic //////////////////////////
//     double x = 10 * (goal->cell.x - from->cell.x);
//     double y = 10 * (goal->cell.y - from->cell.y);
//     return floor(sqrt(pow(x, 2) + pow(y, 2)));
// }
// double g_cost(Node* from, Node* goal, const ObstacleDistanceGrid& distances, const SearchParams& params)
// {
//     ////////////////// TODO: Implement your goal cost, use obstacle distances //////////////////////////
//     double x = abs(from->cell.x - goal->cell.x);
//     double y = abs(from->cell.y - goal->cell.y);
//     if (x == 1 && y == 1) {
//         return from->g_cost + 14 + 20/distances.operator()(from->cell.x,from->cell.y);
//     } else {
//         return from->g_cost + 10 + 20/distances.operator()(from->cell.x,from->cell.y);
//     }
// }

// std::vector<Node*> expand_node(Node* node, const ObstacleDistanceGrid& distances, const SearchParams& params, const PriorityQueue& searched)
// {
//     std::vector<Node*> children;
//     ////////////////// TODO: Implement your expand node algorithm //////////////////////////
//     double x_deltas[8] = {1, -1, 0,  0, 1, 1, -1, -1};
//     double y_deltas[8] = {0,  0, 1, -1, 1, -1, 1, -1};

//     int parent_x = node->cell.x;
//     int parent_y = node->cell.y;

//     for (int i = 0; i < 8; i++) {
//         if (!distances.isCellInGrid(parent_x + x_deltas[i], parent_y + y_deltas[i])) {
//             continue;
//         }

//         Node* child;
//         bool found_in_searched = false;
//         for (int j = 0; j < searched.elements.size(); j++) {
//             Node* curr_searched = searched.elements[j];
//             if ((curr_searched->cell.x == parent_x + x_deltas[i]) && (curr_searched->cell.y == parent_y + y_deltas[i])) {
//                 child = curr_searched;
//                 found_in_searched = true;
//                 break;
//             }
//         }
//         if (!found_in_searched) {
//             child = new Node(parent_x + x_deltas[i], parent_y + y_deltas[i]);
//         }
//         children.push_back(child);
//     }
    
//     return children;
// }

// std::vector<Node*> extract_node_path(Node* goal_node, Node* start_node)
// {
//     std::vector<Node*> path;
//     ////////////////// TODO: Implement your extract node function //////////////////////////
//     // Traverse nodes and add parent nodes to the vector

//     Node* curr_node = goal_node;
//     int p = 0;
//     //printf("in extract curr node x %d y %d goal node x %d y %d start node x %d y %d\n", curr_node->cell.x, curr_node->cell.y, goal_node->cell.x, goal_node->cell.y, start_node->cell.x, start_node->cell.y);
//     while ((curr_node->cell.x != start_node->cell.x) || (curr_node->cell.y != start_node->cell.y)) {
//         //printf("curr parent x %d y %d\n", curr_node->parent->cell.x, curr_node->parent->cell.y);
//         path.push_back(curr_node);
//         curr_node = curr_node->parent;
//         p = p + 1;
//     }
//     //printf("OUT OF WHILE, %d\n", p);
//     path.push_back(start_node);
    
//     // Reverse path
//     std::reverse(path.begin(), path.end());
//     return path;
// }
// // To prune the path for the waypoint follower
// std::vector<mbot_lcm_msgs::pose2D_t> extract_pose_path(std::vector<Node*> nodes, const ObstacleDistanceGrid& distances)
// {
//     std::vector<mbot_lcm_msgs::pose2D_t> path;
//     ////////////////// TODO: Implement your extract_pose_path function //////////////////////////
//     // This should turn the node path into a vector of poses (with heading) in the global frame
//     // You should prune the path to get a waypoint path suitable for sending to motion controller
    
//     for (int i = 0; i < nodes.size(); i++) {
//         Node* curr = nodes[i];

//         mbot_lcm_msgs::pose2D_t pose;
//         pose.x = (curr->cell.x) * distances.metersPerCell() + distances.originInGlobalFrame().x;
//         pose.y = (curr->cell.y) * distances.metersPerCell() + distances.originInGlobalFrame().y;
        
//         if (i == nodes.size() - 1) {
//             pose.theta = 0;
//         } else {
//             pose.theta = atan2(nodes[i+1]->cell.y - curr->cell.y, nodes[i+1]->cell.x - curr->cell.x);
//         }
//         path.push_back(pose);
//     }

//     return path;
// }

// bool is_on_same_line(mbot_lcm_msgs::pose2D_t p1, mbot_lcm_msgs::pose2D_t p2, mbot_lcm_msgs::pose2D_t p3){
//     if (p1.x * (p2.y - p3.y) + p2.x * (p3.y - p1.y) + p3.x * (p1.y - p2.y) == 0){
//         return true;
//     }

//     double dx1 = p2.x-p1.x;
//     double dy1 = p2.y-p1.y;

//     double dx2 = p3.x-p2.x;
//     double dy2 = p3.y-p2.y;
//     const double tol = 0.01;

//     if (dx1 == dx2 or dy1 == dy2){
//         return true;
//     }

//     // prevents divide by 0 error
//     // if (dy1 == 0 and dy2 == 0){
//     //     return true;
//     // }
//     // else if(dy1 == 0 or dy1 == 0){
//     //     if(abs(dx1-dx2)<tol){
//     //         return true;
//     //     }
//     //     return false;
//     // }

//     // if (abs(dx1/dy1-dx2/dy2)<tol){
//     //     return true;
//     // }
//     return false;
// }
// mbot_lcm_msgs::path2D_t prune_node_path(mbot_lcm_msgs::path2D_t nodePath)
// {
//     ////////////////// TODO: Optionally implement a prune_node_path function //////////////////////////
//     // This should remove points in the path along the same line
//     if (nodePath.path.size()<=3){
//         return nodePath;
//     }
//     long int size = nodePath.path.size();
//     mbot_lcm_msgs::path2D_t new_node_path;
//     new_node_path.path.push_back(nodePath.path[0]);

//      for(size_t i = 2; i < nodePath.path.size() - 1; i++){
//         mbot_lcm_msgs::pose2D_t p1 = nodePath.path[i - 1];
//         mbot_lcm_msgs::pose2D_t p2 = nodePath.path[i];
//         mbot_lcm_msgs::pose2D_t p3 = nodePath.path[i + 1];

//         // Check if they are on the same line
//         if (!is_on_same_line(p1, p2, p3)) {
//             new_node_path.path.push_back(p2);
//         }
//     }
//     new_node_path.path.push_back(nodePath.path.back());
//     new_node_path.path_length = new_node_path.path.size();
    
//     return new_node_path;
// }
#include <planning/astar.hpp>
#include <algorithm>
#include <chrono>
#include <cmath>
#include <iostream>
#include <queue>
#include <unordered_map>

using namespace std::chrono;

mbot_lcm_msgs::path2D_t search_for_path(mbot_lcm_msgs::pose2D_t start,
                                        mbot_lcm_msgs::pose2D_t goal,
                                        const ObstacleDistanceGrid &distances,
                                        const SearchParams &params)
{
    cell_t startCell = global_position_to_grid_cell(Point<double>(start.x, start.y), distances);
    cell_t goalCell = global_position_to_grid_cell(Point<double>(goal.x, goal.y), distances);
    bool found_path = false;

    ////////////////// TODO(DONE): Implement your A* search here //////////////////////////

    Node *startNode = new Node(startCell.x, startCell.y);
    Node *goalNode = new Node(goalCell.x, goalCell.y);

    auto compare = [](Node *a, Node *b)
    { return (a->g_cost + a->h_cost) > (b->g_cost + b->h_cost); };

    std::priority_queue<Node *, std::vector<Node *>, decltype(compare)> openSet(compare);
    std::unordered_map<int64_t, Node *> allNodes;

    startNode->g_cost = 0;
    startNode->h_cost = h_cost(startNode, goalNode, distances);
    openSet.push(startNode);
    allNodes[grid_cell_to_hash(startNode->cell)] = startNode;

    Node *currentNode = nullptr;

    while (!openSet.empty())
    {
        currentNode = openSet.top();
        openSet.pop();

        if (*currentNode == *goalNode)
        {
            found_path = true;
            break;
        }

        auto neighbors = expand_node(currentNode, distances, params);
        for (auto neighbor : neighbors)
        {
            double tentative_gCost = currentNode->g_cost + g_cost(currentNode, neighbor, distances, params);

            int64_t hash = grid_cell_to_hash(neighbor->cell);
            if (allNodes.find(hash) == allNodes.end() || tentative_gCost < neighbor->g_cost)
            {
                neighbor->g_cost = tentative_gCost;
                neighbor->h_cost = h_cost(neighbor, goalNode, distances);
                neighbor->parent = currentNode;

                if (allNodes.find(hash) == allNodes.end())
                {
                    openSet.push(neighbor);
                    allNodes[hash] = neighbor;
                }
            }
        }
    }

    mbot_lcm_msgs::path2D_t path;
    path.utime = start.utime;
    if (found_path)
    {
        auto nodePath = extract_node_path(currentNode, startNode);
        path.path = extract_pose_path(nodePath, distances);
        path.path.pop_back();
        path.path.push_back(goal);
    }
    else
    {
        std::cout << "[A*] Didn't find a path\n";
    }

    path.path_length = path.path.size();

    for (auto pair : allNodes)
    {
        delete pair.second;
    }

    return path;
}

int64_t grid_cell_to_hash(const cell_t &cell)
{
    // generate hash value for node
    const int prime = 10000019;
    int64_t hashValue = 1;
    hashValue = prime * hashValue + cell.x;
    hashValue = prime * hashValue + cell.y;
    return hashValue;
}

double h_cost(Node *from, Node *goal, const ObstacleDistanceGrid &distances)
{
    double h_cost = 0.0;
    ////////////////// TODO(DONE): Implement your heuristic //////////////////////////
    int dx = abs(from->cell.x - goal->cell.x);
    int dy = abs(from->cell.y - goal->cell.y);
    h_cost = (dx + dy) + (sqrt(2.0) - 2) * std::min(dx, dy);
    return h_cost;
}

double g_cost(Node *from, Node *goal, const ObstacleDistanceGrid &distances, const SearchParams &params)
{
    double g_cost = 0.0;
    ////////////////// TODO(DONE): Implement your goal cost, use obstacle distances //////////////////////////

    double dx = abs(goal->cell.x - from->cell.x);
    double dy = abs(goal->cell.y - from->cell.y);
    double distance = sqrt(dx * dx + dy * dy);
    // double distance = (dx + dy) + (sqrt(2.0) - 2) * std::min(dx, dy);

    double obstacleDistanceCost = 0.0;

    double obstacleDistance_goal = distances(goal->cell.x, goal->cell.y);
    if (obstacleDistance_goal < params.maxDistanceWithCost && obstacleDistance_goal > params.minDistanceToObstacle)
    {
        obstacleDistanceCost = pow(params.maxDistanceWithCost - obstacleDistance_goal, params.distanceCostExponent);
    }

    double obstacleDistance_from = distances(from->cell.x, from->cell.y);
    if (obstacleDistance_from < params.maxDistanceWithCost && obstacleDistance_from > params.minDistanceToObstacle)
    {
        obstacleDistanceCost += pow(params.maxDistanceWithCost - obstacleDistance_from, params.distanceCostExponent);
    }

    g_cost = distance + obstacleDistanceCost;

    // std::cout << "g cost: distance cost: " << distance << std::endl;
    // std::cout << "g cost: obstacle cost: " << obstacleDistanceCost << std::endl;
    // std::cout << "g cost: " << g_cost << std::endl;

    return g_cost;
}

std::vector<Node *> expand_node(Node *node, const ObstacleDistanceGrid &distances, const SearchParams &params)
{
    std::vector<Node *> children;
    ////////////////// TODO(DONE): Implement your expand node algorithm //////////////////////////
    const int xDeltas[8] = {1, -1, 0, 0, 1, -1, 1, -1};
    const int yDeltas[8] = {0, 0, 1, -1, 1, -1, -1, 1};
    for (int n = 0; n < 8; ++n)
    {
        cell_t adjacentCell(node->cell.x + xDeltas[n], node->cell.y + yDeltas[n]);
        if (distances.isCellInGrid(adjacentCell.x, adjacentCell.y))
        {
            auto distanceToObstacle = distances(adjacentCell.x, adjacentCell.y);
            if (distanceToObstacle > params.minDistanceToObstacle)
            {
                Node *new_node = new Node(adjacentCell.x, adjacentCell.y);
                children.push_back(new_node);
            }
        }
    }

    return children;
}

std::vector<Node *> extract_node_path(Node *goal_node, Node *start_node)
{
    std::vector<Node *> path;
    ////////////////// TODO(DONE): Implement your extract node function //////////////////////////
    // Traverse nodes and add parent nodes to the vector
    Node *cur = goal_node;
    while (cur)
    {
        path.push_back(cur);
        cur = cur->parent;
        if (cur == start_node)
        {
            path.push_back(start_node);
            break;
        }
    }
    // Reverse path
    std::reverse(path.begin(), path.end());
    return path;
}

int64_t get_current_utime()
{
    auto now = std::chrono::system_clock::now();
    auto duration = now.time_since_epoch();
    auto microseconds = std::chrono::duration_cast<std::chrono::microseconds>(duration).count();

    return static_cast<int64_t>(microseconds);
}

std::vector<mbot_lcm_msgs::pose2D_t> extract_pose_path(std::vector<Node *> nodes, const ObstacleDistanceGrid &distances)
{
    std::vector<mbot_lcm_msgs::pose2D_t> path;
    auto nodePath = prune_node_path(nodes);
    if (nodePath.empty())
    {
        std::cout << "node path is empty, error occurs!" << std::endl;
        return path;
    }

    auto globalPose = grid_position_to_global_position(nodePath[0]->cell, distances);

    for (int i = 0; i < nodePath.size(); i++)
    {
        mbot_lcm_msgs::pose2D_t pose;
        pose.x = globalPose.x;
        pose.y = globalPose.y;
        pose.utime = get_current_utime();

        if (i < nodePath.size() - 1)
        {
            auto nextGlobalPos = grid_position_to_global_position(nodePath[i + 1]->cell, distances);
            pose.theta = atan2(nextGlobalPos.y - pose.y, nextGlobalPos.x - pose.x);
            globalPose = nextGlobalPos;
        }
        else
        {
            pose.theta = (i > 0) ? path.back().theta : 0;
        }

        path.push_back(pose); // 添加这一行来更新路径
    }

    return path;
}


bool is_in_list(Node *node, std::vector<Node *> list)
{
    for (auto &&item : list)
    {
        if (*node == *item)
            return true;
    }
    return false;
}

Node *get_from_list(Node *node, std::vector<Node *> list)
{
    for (auto &&n : list)
    {
        if (*node == *n)
            return n;
    }
    return NULL;
}

std::vector<Node *> prune_node_path(std::vector<Node *> nodePath)
{
    std::vector<Node *> new_node_path;
    ////////////////// TODO(DONE): Optionally implement a prune_node_path function //////////////////////////
    // This should remove points in the path along the same line
    if (nodePath.size() < 3)
    {
        return nodePath;
    }
    new_node_path.push_back(nodePath[0]);
    for (int i = 1; i < nodePath.size() - 1; i++)
    {
        Node *prev = nodePath[i - 1];
        Node *curr = nodePath[i];
        Node *next = nodePath[i + 1];
        auto crossProduct = (curr->cell.y - prev->cell.y) * (next->cell.x - curr->cell.x) -
                            (next->cell.y - curr->cell.y) * (curr->cell.x - prev->cell.x);
        if (crossProduct > 1e-2)
        {
            new_node_path.push_back(curr);
        }
    }
    new_node_path.push_back(nodePath.back());

    return new_node_path;
}

